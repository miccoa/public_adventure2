﻿using UnityEngine;
using System.Collections;
using UnityEngine.SceneManagement;

public class EndScreenSceneScript : MonoBehaviour {
	public float currentHealth;
	void Start() {
        //PlayerPrefs.SetFloat ("healtti", 3000);
        GameSceneLevelLoading.levelNumber = 0;
        currentHealth = 0;
    }
	void Update() {

	}
	void endGame(){

	}
	void OnGUI(){
		GUILayout.BeginArea (new Rect ((Screen.width / 2) - 50, (Screen.height / 2), 200, 300));
		GUILayout.Label ("Health is now: " + PlayerHealth.Playerhealth);
		//if (PlayerHealth.Playerhealth == 0) {
			GUILayout.Label ("Game over. Try again?");
		if (GUILayout.Button ("Retry")) {
			SceneManager.LoadScene ("GameScene");

			PlayerHealth.Playerhealth = 20f;
			Inventory.money = 500;
			Inventory.maxHealth = 20.0f; //sliderissa lisää
			Inventory.maxMana = 1.0f;

			Inventory.manaRegen = 0.5f;

			Inventory.nopeus = 42.0f;
			//Inventory.vaikeustas;//vaikeustason valinta
			//public static Color varihahmolle; //väri

			Inventory.fireLevel = 1;
			Inventory.airLevel = 1;
			Inventory.iceLevel = 1;

			Inventory.key = true;

			Inventory.shopTokens = 3;
		}
			//GUILayout.Label ("Main menu");
			if (GUILayout.Button ("Quit to main menu"))
				SceneManager.LoadScene ("MainMenu");
		//}
		GUILayout.EndArea ();
		
		//if (currentHealth == 0)
		//	endGame ();
	}
}
