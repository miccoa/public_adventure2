﻿using UnityEngine;
using System.Collections;

public class ButtonMechanics : MonoBehaviour {
	
}
