﻿using UnityEngine;
using System.Collections;

public class MainMenuResetPlayer : MonoBehaviour {

	// Use this for initialization
	void Start () {
        if(Inventory.inventory != null)
            Inventory.inventory.Clear();
        Inventory.money = 500;
        Inventory.maxHealth = 20.0f; //sliderissa lisää
        Inventory.maxMana = 1.0f;

        Inventory.manaRegen = 0.5f;

        Inventory.nopeus = 42.0f;

        Inventory.fireLevel = 1;
        Inventory.airLevel = 1;
        Inventory.iceLevel = 1;

        Inventory. key = true;

        Inventory.shopTokens = 3;

        Time.timeScale = 1f;

        Player.smallBar = 0; //this could be bool
    }
	
	// Update is called once per frame
	void Update () {
	
	}
}
