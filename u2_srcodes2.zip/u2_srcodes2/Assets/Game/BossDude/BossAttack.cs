﻿using UnityEngine;
using System.Collections;

//yes this is the boss animate the body, left and right hand movements
//coded by shmup team

public class BossAttack : MonoBehaviour {
	
    float timetoattack;
	public static bool startboss; 
    Animator anim;
    Animator animLeftHand;
    Animator animRightHand;

    bool attack;
    float attacktime;
    float isRightAttack = 0;
    bool TimeCounter = true;
	// Use this for initialization
	void Start () {
		//if (startboss == true) {
			timetoattack = 0;
			anim = GetComponent<Animator> ();
			animLeftHand = transform.FindChild ("left").GetComponent<Animator> ();
			animRightHand = transform.FindChild ("right").GetComponent<Animator> ();
			attack = false;   
			attacktime = 2;
		//}
       
    }
	
	// Update is called once per frame
	void Update () {
		if (startboss == true) {
			if (TimeCounter) {
			
				timetoattack -= Time.deltaTime;

				if (timetoattack < 1) {
					TimeCounter = false;
				}        
			}


			if (TimeCounter == false && attack == false) {
				attack = true;
				isRightAttack = Random.RandomRange (0f, 2f);
			}


			if (isRightAttack < 1) {
				if (attack == true) {
					attacktime -= Time.deltaTime;
					anim.SetBool ("AttackLeft", attack);
					animLeftHand.SetBool ("AttackLeft", attack);
					animRightHand.SetBool ("AttackLeft", attack);


					if (attacktime <= 0) {
						attack = false;
						attacktime = 2;
						timetoattack = 5;
						TimeCounter = true;
						anim.SetBool ("AttackLeft", attack);
						animLeftHand.SetBool ("AttackLeft", attack);
						animRightHand.SetBool ("AttackLeft", attack);
					}
				}
			}



			if (isRightAttack > 1) {
				if (attack == true) {
					attacktime -= Time.deltaTime;
					anim.SetBool ("AttackRight", attack);
					animLeftHand.SetBool ("AttackRight", attack);
					animRightHand.SetBool ("AttackRight", attack);


					if (attacktime <= 0) {
						attack = false;
						attacktime = 2;
						timetoattack = 5;
						TimeCounter = true;
						anim.SetBool ("AttackRight", attack);
						animLeftHand.SetBool ("AttackRight", attack);
						animRightHand.SetBool ("AttackRight", attack);
					}
				}
			}


		}
        }

}
