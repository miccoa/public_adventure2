﻿using UnityEngine;
using System.Collections;
using System.Collections.Generic;
using UnityEngine.SceneManagement;
using UnityEngine.UI;

public class PlayerBoss : MonoBehaviour {

	Rigidbody2D rb;
	float multiplier = 0.002f;
	float addition = 2.0f;
	private Animator anim;
	public Image FadeImg;

	// Use this for initialization
	void Start () {
		rb = GetComponent<Rigidbody2D>();
		anim = GetComponent<Animator>();

	}
	
	// Update is called once per frame
	void Update () {
	
	}
	void FixedUpdate()
	{
		rb.velocity += Vector2.up * (Inventory.nopeus + addition) * multiplier;
		anim.Play ("PlayerWalkingUp");
	}
	//also found on player.cs
	IEnumerator FadeBlack(float Value, float Time2)//fade
	{
		Color testFading = FadeImg.color; 
		float alpha = testFading.a;
		alpha = 1; //fadetus color.clear to color.black. 
		//0, 0, 0, 1 similar color according unity ref.. color.clear:n kanssa.

		for (float t = 1.0f; t > 0.0f; t -= Time.deltaTime / Time2)
		{

			Color newColor = new Color(0, 0, 0, Mathf.Lerp(alpha, Value,t));
			FadeImg.color = newColor;

			yield return 2;
		}
	}
	IEnumerator odotawon(float timeparam)
	{
		yield return new WaitForSeconds(timeparam);

		SceneManager.LoadScene("Boss");

	}
	void OnCollisionEnter2D(Collision2D other)
	{
		
		if (other.gameObject.tag == "Finish") {

			//GameSceneLevelLoading.levelNumber++;


			FadeImg.rectTransform.localScale = new Vector2 (Screen.width, Screen.height);
			StartCoroutine (FadeBlack (0.0f, 1.0f)); //fading to black using black img
			StartCoroutine(odotawon(1.0f));


		}

	}
}
