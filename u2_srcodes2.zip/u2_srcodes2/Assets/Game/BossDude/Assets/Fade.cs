﻿using UnityEngine;
using System.Collections;
using UnityEngine.UI;

public class Fade : MonoBehaviour {
	public Image FadeImg;
	// Use this for initialization
	void Start () {
		FadeImg.rectTransform.localScale = new Vector2 (Screen.width, Screen.height);
		StartCoroutine (FadeBlack (1.0f, 1.0f)); //fading to black using black img

		//StartCoroutine (odota (0.2f));
	}
	
	// Update is called once per frame
	void Update () {
	
	}//fading from black to clear
	IEnumerator FadeBlack(float Value, float Time2)//fade
	{
		Debug.Log ("called fade");
		Color testFading = FadeImg.color; 
		float alpha = testFading.a;
		alpha = 0; //fadetus color.clear to color.black. 
		//0, 0, 0, 1 on black color.
		//unity ref. mukaan yhtäläin. color.clear:n kanssa.

		for (float t = 1.0f; t > 0.0f; t -= Time.deltaTime / Time2)
		{

			Color newColor = new Color(0, 0, 0, Mathf.Lerp(alpha, Value,t));
			FadeImg.color = newColor;

			yield return 2;
		}
		BossAttack.startboss = true;
	}
	IEnumerator odota(float timeparam)
	{
		yield return new WaitForSeconds(timeparam);


	}
}
