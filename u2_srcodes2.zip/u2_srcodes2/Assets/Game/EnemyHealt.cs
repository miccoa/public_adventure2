﻿using UnityEngine;
using System.Collections;
using UnityEngine.UI;
using UnityEngine.SceneManagement;

public class EnemyHealt : MonoBehaviour {

    public float EnemyHealtti;
    Image HealthImage;
    public GameObject EnemyHitParticle;
    public GameObject ManaCrystal;
    public Element element;
	private Animator anim;
	private BoxCollider2D box2d;
	bool playedClipOnce = false;
    public bool alive;

    private float maxHealth;
        
    // Use this for initialization
    void Start () {
        alive = true;
		box2d = GetComponent<BoxCollider2D> ();
        maxHealth = EnemyHealtti;
        HealthImage = transform.FindChild("EnemyHealthCanvas").FindChild("Health").GetComponent<Image>();
		anim = GetComponent<Animator>();
	}
	//let's wait for a while
	IEnumerator odota(float timeparam)
	{
		yield return new WaitForSeconds(timeparam);
		Destroy(gameObject);
		//SceneManager.LoadScene("EndScreenScene");

	}
	// Update is called once per frame
	void Update () {

        if (EnemyHealtti < 0)
        {
            EnemyHealtti = 0;
        }

        if (EnemyHealtti > 4)
        {
            EnemyHealtti = 4;

        }

        if (EnemyHealtti <= 0)
        {
            alive = false;
			box2d.enabled = false;
			
			anim.SetBool ("Gone", true);

            int r = Random.Range(0, 4);
            for (int i = 0; i < r; i++)
            {
                GameObject o = Instantiate(ManaCrystal);
                o.GetComponent<Rigidbody2D>().AddForce(new Vector2(Random.Range(-50, 50), Random.Range(-50, 50)));
                o.transform.position = transform.position;
            }

			StartCoroutine(odota(0.8f));
			if (playedClipOnce == false) {

				playedClipOnce = true;
			} else {

				playedClipOnce = true;

			}

			anim.enabled = true;

        }
        HealthImage.transform.localScale = new Vector3(EnemyHealtti / maxHealth, 1, 1);
    }


    void OnTriggerEnter2D(Collider2D other)
    {

        if (other.gameObject.tag == "bullet")
        {
			Instantiate(EnemyHitParticle,transform.position,transform.rotation);//enemy touched and notified
            float damage = other.gameObject.GetComponent<Bullet>().damage;
            if (element != other.gameObject.GetComponent<Bullet>().element)
                damage *= 2;
			if (Player.element == Element.Air) { 
				if (element == Element.Air) {
					damage = 1f;
				}
				if (element == Element.Fire) {
					damage = 2f;//instawin
				}
				if (element == Element.Ice) {
					damage = 30f;//instawin
				}
			}
			if (Player.element == Element.Fire) { 
				if (element == Element.Air) {
					damage = 100f;
				}
				if (element == Element.Fire) {
					damage = 1f;//instawin
				}
				if (element == Element.Ice) {
					damage = 2f;//instawin
				}
			}
			if (Player.element == Element.Ice) { 
				if (element == Element.Air) {
					damage = 2f;
				}
				if (element == Element.Fire) {
					damage = 50f;//instawin
				}
				if (element == Element.Ice) {
					damage = 1f;//instawin
				}
			}
            EnemyHealtti -= damage;
            Destroy(other.gameObject);
        }
		if (other.gameObject.tag == "Player") {
			if (Player.clickedTwiceSoon == false) { //jtn
				Instantiate (EnemyHitParticle, transform.position, transform.rotation);//enemy touched and notified
				float damage = 5f; //other.gameObject.GetComponent<Bullet> ().damage;
                EnemyHealtti -= damage;
                //if (element != other.gameObject.GetComponent<Bullet> ().element)
                //	damage *= 2;
                //tuli, jää, ilma, tuli voittaa ilman, ilma voittaa jään, jää voittaa tulen

                //EnemyHealtti -= damage;
            }
		}
    }

}
