﻿using UnityEngine;
using System.Collections;
using UnityEngine.SceneManagement;

public class WinScreenSceneScript : MonoBehaviour {
	public float currentHealth;
	void Start() {
        //PlayerPrefs.SetFloat ("healtti", 3000);
        GameSceneLevelLoading.levelNumber = 0;
        currentHealth = 0;
    }
	void Update() {

	}
	void endGame(){

	}
	void OnGUI(){
		GUILayout.BeginArea (new Rect ((Screen.width / 2) - 50, (Screen.height / 2), 200, 300));
		GUILayout.Label ("It seems you have won. Congrats. : \n" + PlayerHealth.Playerhealth);
		//if (PlayerHealth.Playerhealth == 0) {
			//GUILayout.Label ("Game over. Try again?");
			//if (GUILayout.Button ("Retry"))
			//	SceneManager.LoadScene ("CharacterSelection");
			//GUILayout.Label ("Main menu");
			if (GUILayout.Button ("Get to the main menu"))
				SceneManager.LoadScene ("MainMenu");
		//}
		GUILayout.EndArea ();
		
		//if (currentHealth == 0)
		//	endGame ();
	}
}
