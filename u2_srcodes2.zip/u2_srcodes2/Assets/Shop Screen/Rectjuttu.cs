﻿using UnityEngine;
using System.Collections;

public class Rectjuttu : MonoBehaviour {

	// Use this for initialization
	void Start () {
	
	}
	
	// Update is called once per frame
	void Update () {
	
	}
	void OnGUI ()
	{
		Rect rect = new Rect(new Vector2(300, 300), new Vector2(256, 80));//mousepos.x ja -y: -8
	}
}
